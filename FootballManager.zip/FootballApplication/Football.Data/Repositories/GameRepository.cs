﻿using Football.Data.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Football.Data.Repositories
{
    public class GameRepository
    {
        private readonly FootballContext context;

        public GameRepository(FootballContext context)
        {
            this.context = context;
        }

        public async Task AddAsync(Game game)
        {
            await context.AddAsync(game);
            await context.SaveChangesAsync();
        }

        public async Task<List<Game>> GetAllAsync() =>
            await context.Games.Select(x => x)
            .Include(x => x.TeamOne)
                .ThenInclude(x => x.Players)
            .Include(x => x.TeamTwo)
                .ThenInclude(x => x.Players)
            .Include(x => x.Stadium)
            .ToListAsync();

        public async Task DeleteAsync(Game game)
        {
            context.Games.Remove(game);
            await context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Game game)
        {
            context.Games.Update(game);
            await context.SaveChangesAsync();
        }

    }
}
