﻿using Football.Data.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Football.Data.Repositories
{
    public class PlayerRepository
    {
        private readonly FootballContext context;

        public PlayerRepository(FootballContext context)
        {
            this.context = context;
        }

        public async Task AddRangeAsync(IList<Player> players)
        {
            await context.Players.AddRangeAsync(players);
            await context.SaveChangesAsync();
        }
    }
}
