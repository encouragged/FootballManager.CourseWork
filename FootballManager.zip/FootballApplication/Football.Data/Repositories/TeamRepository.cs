﻿using Football.Data.Entities;
using Football.Data.Entities.Enumerations;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Football.Data.Repositories
{
    public class TeamRepository
    {
        private readonly FootballContext context;

        public TeamRepository(FootballContext context)
        {
            this.context = context;
        }

        public async Task AddAsync(Team team)
        {
            await context.Teams.AddAsync(team);
            await context.SaveChangesAsync();
        }

        public async Task<List<Team>> GetAllAsync() =>
            await context.Teams.Select(x => x).Include(x => x.Players).ToListAsync();

        public async Task<bool> IsTeamExists(string name) =>
            await context.Teams.FirstOrDefaultAsync(x => x.Name == name) == null ? false : true;
    }
}
