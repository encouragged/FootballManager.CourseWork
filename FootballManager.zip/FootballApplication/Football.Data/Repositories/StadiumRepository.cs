﻿using Football.Data.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Football.Data.Repositories
{
    public class StadiumRepository
    {
        private readonly FootballContext context;

        public StadiumRepository(FootballContext context)
        {
            this.context = context;
        }

        public async Task<List<Stadium>> GetAllAsync() =>
            await context.Stadiums.Select(x => x).Include(x => x.Games).ToListAsync();

        public async Task AddAsync(Stadium stadium)
        {
            await context.Stadiums.AddAsync(stadium);
            await context.SaveChangesAsync();
        }

        public async Task UpdateAsync(Stadium stadium)
        {
            context.Stadiums.Update(stadium);
            await context.SaveChangesAsync();
        }

        public async Task DeleteAsync(Stadium stadium)
        {
            context.Stadiums.Remove(stadium);
            await context.SaveChangesAsync();
        }
    }
}
