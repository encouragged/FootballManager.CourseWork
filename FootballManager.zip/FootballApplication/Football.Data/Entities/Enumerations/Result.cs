﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Football.Data.Entities.Enumerations
{
    public enum Result
    {
        T1Win,
        T2Win,
        Draft,
        Proceed,
        Planned
    }
}
