﻿namespace Football.Data.Entities.Enumerations
{
    public enum HealthStatus
    {
        Healthy,
        Injured
    }
}
