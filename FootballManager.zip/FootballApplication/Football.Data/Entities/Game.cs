﻿using Football.Data.Entities.Enumerations;
using System;
using System.Collections.Generic;

namespace Football.Data.Entities
{
    public class Game
    {
        public int Id { get; set; }
        public DateTime Date { get; set; }
        public int Viewers { get; set; }
        public Result Result { get; set; }
        public Stadium Stadium { get; set; }
        public int StadiumId { get; set; }
        public Team TeamOne { get; set; }
        public Team TeamTwo { get; set; }

    }
}
