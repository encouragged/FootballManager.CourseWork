﻿using System.Collections.Generic;

namespace Football.Data.Entities
{
    public class Stadium
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Seats { get; set; }
        public double PricePerSeat { get; set; }
        public List<Game> Games { get; set; }
    }
}
