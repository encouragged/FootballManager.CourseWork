﻿using Football.Core.Exceptions;
using Football.Data.Entities;
using Football.Data.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Football.Core.Services
{
    public class StadiumService
    {
        private readonly StadiumRepository stadiumRepository;

        public StadiumService(StadiumRepository stadiumRepository)
        {
            this.stadiumRepository = stadiumRepository;
        }

        public async Task ValidateAndAddAsync(string name, int seats, double pricePerSeat)
        {
            if (seats > 0)
            {
                if (pricePerSeat > 0)
                {
                    var stadium = new Stadium
                    {
                        Name = name,
                        Seats = seats,
                        PricePerSeat = pricePerSeat
                    };

                    await stadiumRepository.AddAsync(stadium);
                }
                else
                {
                    throw new StadiumException("Price per seat can not be lower than zero!");
                }
                
            }
            else
            {
                throw new StadiumException("Seats can not be lower than zero!");
            }
        }

        public async Task<List<Stadium>> GetAllAsync() =>
            await stadiumRepository.GetAllAsync();

        public async Task UpdateAsync(string name, int seats, double pricePerSeat)
        {
            var stadiums = await GetAllAsync();
            var stadium = stadiums.FirstOrDefault(x => x.Name == name);

            stadium.Seats = seats;
            stadium.PricePerSeat = pricePerSeat;

            await stadiumRepository.UpdateAsync(stadium);
        }

        public async Task DeleteAsync(string name)
        {
            var stadiums = await GetAllAsync();
            var stadium = stadiums.FirstOrDefault(x => x.Name == name);

            await stadiumRepository.DeleteAsync(stadium);
        }
    }
}
