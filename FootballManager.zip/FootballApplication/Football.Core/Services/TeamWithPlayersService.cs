﻿using Football.Core.Exceptions;
using Football.Data.Entities;
using Football.Data.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Football.Core.Services
{
    public class TeamWithPlayersService
    {
        private readonly TeamRepository teamRepository;
        private readonly PlayerRepository playerRepository;

        public TeamWithPlayersService(TeamRepository teamRepository, PlayerRepository playerRepository)
        {
            this.teamRepository = teamRepository;
            this.playerRepository = playerRepository;
        }

        public async Task CreatingTeamWithPlayersAsync(string teamName, IList<Player> players)
        {
            await ValidateTeamExistance(teamName);

            var team = new Team
            {
                Name = teamName
            };

            foreach (var player in players)
            {
                player.Team = team;
            }

            await teamRepository.AddAsync(team);
            await playerRepository.AddRangeAsync(players);
        }

        public async Task<List<Team>> GetAllTeamsWithRelatedPlayers() =>
            await teamRepository.GetAllAsync();

        private async Task ValidateTeamExistance(string name)
        {
            if (await teamRepository.IsTeamExists(name))
            {
                throw new ExistanceException("The team with set name is already exists!");
            }
        }
    }
}
