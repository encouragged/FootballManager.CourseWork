﻿using Football.Core.Exceptions;
using Football.Data.Entities;
using Football.Data.Entities.Enumerations;
using Football.Data.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Football.Core.Services
{
    public class GameService
    {
        private readonly GameRepository gameRepository;
        private readonly TeamRepository teamRepository;
        private readonly StadiumRepository stadiumRepository;

        public GameService(GameRepository gameRepository, StadiumRepository stadiumRepository, TeamRepository teamRepository)
        {
            this.gameRepository = gameRepository;
            this.teamRepository = teamRepository;
            this.stadiumRepository = stadiumRepository;
        }

        public async Task CreateGameAsync(int viewers, DateTime date, string stadiumName, string teamOneName, string teamTwoName)
        {
            var stadiums = await stadiumRepository.GetAllAsync();
            var teams = await teamRepository.GetAllAsync();

            var stadium = stadiums.FirstOrDefault(x => x.Name == stadiumName);
            var teamOne = teams.FirstOrDefault(x => x.Name == teamOneName);
            var teamTwo = teams.FirstOrDefault(x => x.Name == teamTwoName);

            if (stadium == null || teamOne == null || teamTwo == null)
            {
                throw new ExistanceException("Stadium or teams are not exist with current names!");
            }

            var game = new Game
            {
                Viewers = Convert.ToInt32(viewers),
                Date = date,
                Result = Result.Planned,
                Stadium = stadium,
                TeamOne = teamOne,
                TeamTwo = teamTwo
            };

            await gameRepository.AddAsync(game);
        }

        public async Task<List<Game>> GetAllWithRelated() =>
            await gameRepository.GetAllAsync();

        public async Task DeleteByIdAsync(int id)
        {
            var games = await GetAllWithRelated();
            var game = games.FirstOrDefault(x => x.Id == id);
            await gameRepository.DeleteAsync(game);
        }

        public async Task UpdateAsync(int id, int viewers, DateTime date, string result, string stadiumName, string teamOneName, string teamTwoName)
        {
            var games = await GetAllWithRelated();
            var game = games.FirstOrDefault(x => x.Id == id);

            var stadiums = await stadiumRepository.GetAllAsync();
            var teams = await teamRepository.GetAllAsync();

            var stadium = stadiums.FirstOrDefault(x => x.Name == stadiumName);
            var teamOne = teams.FirstOrDefault(x => x.Name == teamOneName);
            var teamTwo = teams.FirstOrDefault(x => x.Name == teamTwoName);

            if (stadium == null || teamOne == null || teamTwo == null)
            {
                throw new ExistanceException("Stadium or teams are not exist with current names!");
            }
            var updatedResult = Result.Draft;

            switch (result)
            {
                case nameof(Result.T1Win):
                    updatedResult = Result.T1Win;
                    break;
                case nameof(Result.T2Win):
                    updatedResult = Result.T2Win;
                    break;
                case nameof(Result.Planned):
                    updatedResult = Result.Planned;
                    break;
                case nameof(Result.Proceed):
                    updatedResult = Result.Proceed;
                    break;

                default:
                    break;
            }



            game.Stadium = stadium;
            game.TeamOne = teamOne;
            game.TeamTwo = teamTwo;
            game.Date = date;
            game.Result = updatedResult;

            await gameRepository.UpdateAsync(game);

        }
    }
}
