﻿
namespace Football.UI.Forms
{
    partial class AddGameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.addGameMenuLabel = new System.Windows.Forms.Label();
            this.viewersTB = new System.Windows.Forms.TextBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.stadiumCB = new System.Windows.Forms.ComboBox();
            this.teamOneCB = new System.Windows.Forms.ComboBox();
            this.teamTwoCB = new System.Windows.Forms.ComboBox();
            this.addButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // addGameMenuLabel
            // 
            this.addGameMenuLabel.AutoSize = true;
            this.addGameMenuLabel.Font = new System.Drawing.Font("Bahnschrift Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.addGameMenuLabel.Location = new System.Drawing.Point(71, 35);
            this.addGameMenuLabel.Name = "addGameMenuLabel";
            this.addGameMenuLabel.Size = new System.Drawing.Size(199, 33);
            this.addGameMenuLabel.TabIndex = 0;
            this.addGameMenuLabel.Text = "ADD NEW GAME MENU";
            // 
            // viewersTB
            // 
            this.viewersTB.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.viewersTB.Location = new System.Drawing.Point(90, 82);
            this.viewersTB.Name = "viewersTB";
            this.viewersTB.Size = new System.Drawing.Size(157, 30);
            this.viewersTB.TabIndex = 2;
            this.viewersTB.Text = "Viewers";
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.Red;
            this.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exitButton.Location = new System.Drawing.Point(257, 9);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 3;
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.dateTimePicker1.Location = new System.Drawing.Point(90, 115);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(157, 23);
            this.dateTimePicker1.TabIndex = 4;
            // 
            // stadiumCB
            // 
            this.stadiumCB.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.stadiumCB.FormattingEnabled = true;
            this.stadiumCB.Location = new System.Drawing.Point(90, 144);
            this.stadiumCB.Name = "stadiumCB";
            this.stadiumCB.Size = new System.Drawing.Size(157, 31);
            this.stadiumCB.TabIndex = 5;
            // 
            // teamOneCB
            // 
            this.teamOneCB.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.teamOneCB.FormattingEnabled = true;
            this.teamOneCB.Location = new System.Drawing.Point(90, 181);
            this.teamOneCB.Name = "teamOneCB";
            this.teamOneCB.Size = new System.Drawing.Size(157, 31);
            this.teamOneCB.TabIndex = 9;
            // 
            // teamTwoCB
            // 
            this.teamTwoCB.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.teamTwoCB.FormattingEnabled = true;
            this.teamTwoCB.Location = new System.Drawing.Point(90, 218);
            this.teamTwoCB.Name = "teamTwoCB";
            this.teamTwoCB.Size = new System.Drawing.Size(157, 31);
            this.teamTwoCB.TabIndex = 7;
            // 
            // addButton
            // 
            this.addButton.BackColor = System.Drawing.Color.Lime;
            this.addButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addButton.Font = new System.Drawing.Font("Bahnschrift Condensed", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.addButton.Location = new System.Drawing.Point(90, 255);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(157, 57);
            this.addButton.TabIndex = 8;
            this.addButton.Text = "Add game!";
            this.addButton.UseVisualStyleBackColor = false;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // AddGameForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(343, 330);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.teamTwoCB);
            this.Controls.Add(this.teamOneCB);
            this.Controls.Add(this.stadiumCB);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.viewersTB);
            this.Controls.Add(this.addGameMenuLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddGameForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Adding football game";
            this.Load += new System.EventHandler(this.AddGameForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label addGameMenuLabel;
        private System.Windows.Forms.TextBox viewersTB;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox stadiumCB;
        private System.Windows.Forms.ComboBox teamOneCB;
        private System.Windows.Forms.ComboBox teamTwoCB;
        private System.Windows.Forms.Button addButton;
    }
}