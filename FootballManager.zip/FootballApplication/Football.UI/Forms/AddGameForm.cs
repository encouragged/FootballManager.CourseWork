﻿using Football.Core.Exceptions;
using Football.Core.Services;
using Football.Data.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Football.UI.Forms
{
    public partial class AddGameForm : Form
    {
        private readonly StadiumService stadiumService;
        private readonly TeamWithPlayersService teamWithPlayersService;
        private readonly GameService gameService;

        public AddGameForm(StadiumService stadiumService, TeamWithPlayersService teamWithPlayersService, GameService gameService)
        {
            InitializeComponent();
            this.stadiumService = stadiumService;
            this.teamWithPlayersService = teamWithPlayersService;
            this.gameService = gameService;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private async void addButton_Click(object sender, EventArgs e)
        {
            try
            {
                await gameService.CreateGameAsync(Convert.ToInt32(viewersTB.Text), dateTimePicker1.Value, stadiumCB.SelectedItem.ToString(), 
                    teamOneCB.SelectedItem.ToString(), teamTwoCB.SelectedItem.ToString());
                MessageBox.Show("Game has been successfully added!");
            }
            catch (ExistanceException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch
            {
                MessageBox.Show("Incorrect values in text boxes while adding game!");
            }
        }

        public async void AddGameForm_Load(object sender, EventArgs e)
        {
            stadiumCB.Items.Clear();
            teamOneCB.Items.Clear();
            teamTwoCB.Items.Clear();


            var stadiums = await stadiumService.GetAllAsync();
            stadiumCB.Items.AddRange(stadiums.Select(x => x.Name).ToArray());

            var teams = await teamWithPlayersService.GetAllTeamsWithRelatedPlayers();
            teamOneCB.Items.AddRange(teams.Select(x => x.Name).ToArray());
            teamTwoCB.Items.AddRange(teams.Select(x => x.Name).ToArray());
        }
    }
}
