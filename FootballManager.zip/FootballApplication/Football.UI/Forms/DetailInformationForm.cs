﻿using Football.Core.Services;
using Football.Data.Entities.Enumerations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Football.UI.Forms
{
    public partial class DetailInformationForm : Form
    {
        private bool IsStadiumUpdateEnabled { get; set; } = false;
        private bool IsGameUpdateEnabled { get; set; } = false;

        private readonly StadiumService stadiumService;
        private readonly GameService gameService;
        private readonly TeamWithPlayersService teamWithPlayersService;

        public DetailInformationForm(StadiumService stadiumService, GameService gameService, TeamWithPlayersService teamWithPlayersService)
        {
            InitializeComponent();
            this.stadiumService = stadiumService;
            this.gameService = gameService;
            this.teamWithPlayersService = teamWithPlayersService;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            var stadiums = await stadiumService.GetAllAsync();
            var stadium = stadiums.FirstOrDefault(x => x.Name == textBox1.Text);

            textBox2.Text = stadium.Seats.ToString();
            textBox3.Text = stadium.PricePerSeat.ToString();
        }

        private async void button2_Click(object sender, EventArgs e)
        {
            if (IsStadiumUpdateEnabled)
            {
                IsStadiumUpdateEnabled = false;

                button2.Text = "Update";
                button2.BackColor = Color.Orchid;
                textBox1.ReadOnly = false;
                textBox2.ReadOnly = true;
                textBox3.ReadOnly = true;

                try
                {
                    await stadiumService.UpdateAsync(textBox1.Text, Convert.ToInt32(textBox2.Text), Convert.ToDouble(textBox3.Text));
                    MessageBox.Show($"Stadium with name {textBox1.Text} has been successfully updated!");
                }
                catch
                {
                    MessageBox.Show("Incorrect values while updating stadium! Try again!");
                }
                
            }
            else
            {
                IsStadiumUpdateEnabled = true;

                button2.Text = "Save";
                button2.BackColor = Color.OrangeRed;
                textBox1.ReadOnly = true;
                textBox2.ReadOnly = false;
                textBox3.ReadOnly = false;
            }
        }

        private async void button5_Click(object sender, EventArgs e)
        {
            try
            {
                await stadiumService.DeleteAsync(textBox1.Text);
                MessageBox.Show($"Stadium with name {textBox1.Text} has been successfully deleted!");
            }
            catch
            {
                MessageBox.Show("Incorrect name while deleting stadium! Try again!");
            }
        }

        private async  void button4_Click(object sender, EventArgs e)
        {
            var games = await gameService.GetAllWithRelated();
            var game = games.FirstOrDefault(x => x.Id == Convert.ToInt32(textBox6.Text));
            viewersTB.Text = game.Viewers.ToString();
            dateTimePicker1.Value = game.Date;
            teamOneCB.SelectedItem = game.TeamOne.Name;
            teamTwoCB.SelectedItem = game.TeamTwo.Name;
            stadiumCB.SelectedItem = game.Stadium.Name;
            resultCB.SelectedItem = game.Result.ToString();

        }

        private async void button6_Click(object sender, EventArgs e)
        {
            try
            {
                await gameService.DeleteByIdAsync(Convert.ToInt32(textBox6.Text));
                MessageBox.Show($"Game with ID {textBox6.Text} has been successfully deleted!");
            }
            catch
            {
                MessageBox.Show("Incorrect name while deleting game! Try again!");
            }
        }

        public async void DetailInformationForm_Load(object sender, EventArgs e)
        {
            stadiumCB.Items.Clear();
            teamOneCB.Items.Clear();
            teamTwoCB.Items.Clear();


            var stadiums = await stadiumService.GetAllAsync();
            stadiumCB.Items.AddRange(stadiums.Select(x => x.Name).ToArray());

            var teams = await teamWithPlayersService.GetAllTeamsWithRelatedPlayers();
            teamOneCB.Items.AddRange(teams.Select(x => x.Name).ToArray());
            teamTwoCB.Items.AddRange(teams.Select(x => x.Name).ToArray());

            var results = new string[] { Result.T1Win.ToString(), Result.T2Win.ToString(), Result.Draft.ToString(), 
                Result.Planned.ToString(), Result.Proceed.ToString() };
            resultCB.Items.AddRange(results);
        }

        private async void button3_Click(object sender, EventArgs e)
        {

            if (IsGameUpdateEnabled)
            {
                IsGameUpdateEnabled = false;

                button3.Text = "Update";
                button3.BackColor = Color.Orchid;
                textBox6.ReadOnly = false;
                viewersTB.ReadOnly = true;

                try
                {
                    await gameService.UpdateAsync(Convert.ToInt32(textBox6.Text),
                                                  Convert.ToInt32(viewersTB.Text),
                                                  dateTimePicker1.Value,
                                                  resultCB.SelectedItem.ToString(),
                                                  stadiumCB.SelectedItem.ToString(),
                                                  teamOneCB.SelectedItem.ToString(),
                                                  teamTwoCB.SelectedItem.ToString());
                    MessageBox.Show($"Game with ID {textBox6.Text} has been successfully updated!");
                }
                catch
                {
                    MessageBox.Show("Incorrect values while updating game! Try again!");
                }

            }
            else
            {
                IsGameUpdateEnabled = true;

                button3.Text = "Save";
                button3.BackColor = Color.OrangeRed;
                textBox6.ReadOnly = true;
                viewersTB.ReadOnly = false;
            }
        }
    }
}
