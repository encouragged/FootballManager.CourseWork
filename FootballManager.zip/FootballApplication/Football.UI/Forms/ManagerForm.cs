﻿using Football.Core.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Football.UI.Forms
{
    public partial class ManagerForm : Form
    {
        private bool WasAddGameFormLoaded { get; set; } = false;
        private bool WasInfoFormLoaded { get; set; } = false;

        private readonly AddGameForm addGameForm;
        private readonly AddStadiumForm addStadiumForm;
        private readonly AddTeamForm addTeamForm;
        private readonly GameService gameService;
        private readonly DetailInformationForm detailInformationForm;

        public ManagerForm(AddGameForm addGameForm, AddStadiumForm addStadiumForm, AddTeamForm addTeamForm, GameService gameService, 
            DetailInformationForm detailInformationForm)
        {
            InitializeComponent();
            this.addGameForm = addGameForm;
            this.addStadiumForm = addStadiumForm;
            this.addTeamForm = addTeamForm;
            this.gameService = gameService;
            this.detailInformationForm = detailInformationForm;
        }

        private async void ManagerForm_Load(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            var games = await gameService.GetAllWithRelated();

            foreach (var game in games)
            {
                this.dataGridView1.Rows.Add(game.Id.ToString(), game.TeamOne.Name, game.TeamTwo.Name,
                    game.Date.ToString("dddd, dd MMMM yyyy"), game.Result.ToString(), game.Stadium.Name);
            }
        }

        private void addStadiumButton_Click(object sender, EventArgs e)
        {
            addStadiumForm.Show();

        }

        private void addGameButton_Click(object sender, EventArgs e)
        {
            if (WasAddGameFormLoaded)
            {
                addGameForm.AddGameForm_Load(sender, e);
            }
            else
            {
                WasAddGameFormLoaded = true;
            }

            addGameForm.Show();
        }

        private void addTeamButton_Click(object sender, EventArgs e)
        {
            addTeamForm.Show();
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            ManagerForm_Load(sender, e);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (WasInfoFormLoaded)
            {
                detailInformationForm.DetailInformationForm_Load(sender, e);
            }
            else
            {
                WasInfoFormLoaded = true;
            }
            detailInformationForm.Show();
        }
    }
}
