﻿using Football.Core.Exceptions;
using Football.Core.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Football.UI.Forms
{
    public partial class AddStadiumForm : Form
    {
        private readonly StadiumService stadiumService;

        public AddStadiumForm(StadiumService stadiumService)
        {
            InitializeComponent();
            this.stadiumService = stadiumService;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private async void addButton_Click(object sender, EventArgs e)
        {
            try
            {
                await stadiumService.ValidateAndAddAsync(nameTB.Text, Convert.ToInt32(seatsTB.Text), Convert.ToDouble(priceTB.Text));
                MessageBox.Show($"Successfully added {nameTB.Text} stadium :)");
            }
            catch (StadiumException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch
            {
                MessageBox.Show("Incorrect data in text boxes!");
            }
        }
    }
}
