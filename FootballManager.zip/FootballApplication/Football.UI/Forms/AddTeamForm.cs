﻿using Football.Core.Exceptions;
using Football.Core.Services;
using Football.Data.Entities;
using Football.Data.Entities.Enumerations;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Football.UI.Forms
{
    public partial class AddTeamForm : Form
    {
        private readonly TeamWithPlayersService teamWithPlayersService;

        private List<Player> Players { get; set; } = new List<Player>();
        public AddTeamForm(TeamWithPlayersService teamWithPlayersService)
        {
            InitializeComponent();
            this.teamWithPlayersService = teamWithPlayersService;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void addPlayerButton_Click(object sender, EventArgs e)
        {
            try
            {
                var player = new Player
                {
                    Name = playerNameTB.Text,
                    Surname = playerSurnameTB.Text,
                    DateOfBirth = datePicker.Value,
                    IsActiveStatus = ActiveStatusCB.SelectedItem.ToString() == "Active" ? true : false,
                    HealthStatus = healthStatusCB.SelectedItem.ToString() == HealthStatus.Healthy.ToString() ? HealthStatus.Healthy : HealthStatus.Injured,
                    Salary = Convert.ToInt32(salaryTB.Text)
                };

                Players.Add(player);
                dataGridView1.Rows.Add(player.Name, 
                                        player.Surname, 
                                        player.DateOfBirth.ToString("MM/dd/yyyy"),
                                        player.IsActiveStatus == true ? "Active" : "Not active",
                                        player.HealthStatus.ToString(),
                                        player.Salary);
                dataGridView1.Update();

                MessageBox.Show("Player successfully added to table! Now you should create team with players in table!");
            }
            catch (ExistanceException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch
            {
                MessageBox.Show("Incorrect values in text boxes while adding player!");
            }

            

        }

        private void AddTeamForm_Load(object sender, EventArgs e)
        {
            ActiveStatusCB.Items.AddRange(new string[] { "Active", "Not active" });
            healthStatusCB.Items.AddRange(new string[] { HealthStatus.Healthy.ToString(), HealthStatus.Injured.ToString() });
        }

        private async void addTeamButton_Click(object sender, EventArgs e)
        {
            try
            {
                await teamWithPlayersService.CreatingTeamWithPlayersAsync(teamNameTB.Text, Players);

                MessageBox.Show($"Team {teamNameTB.Text} with {Players.Count} players succesfully created!");
                Players = new List<Player>();

                dataGridView1.Rows.Clear();
            }
            catch
            {
                MessageBox.Show("Invalid values in text boxes! Try again!");
            }
        }

    }
}

