﻿
namespace Football.UI.Forms
{
    partial class AddTeamForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.exitButton = new System.Windows.Forms.Button();
            this.addLabel = new System.Windows.Forms.Label();
            this.teamNameTB = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.nameColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SurnameColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DateOfBirthColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ActiveStatusColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HealthStatusColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SalaryColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.playerNameTB = new System.Windows.Forms.TextBox();
            this.playerSurnameTB = new System.Windows.Forms.TextBox();
            this.datePicker = new System.Windows.Forms.DateTimePicker();
            this.ActiveStatusCB = new System.Windows.Forms.ComboBox();
            this.healthStatusCB = new System.Windows.Forms.ComboBox();
            this.salaryTB = new System.Windows.Forms.TextBox();
            this.addPlayerButton = new System.Windows.Forms.Button();
            this.addTeamButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.Red;
            this.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exitButton.Location = new System.Drawing.Point(766, 7);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 5;
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // addLabel
            // 
            this.addLabel.AutoSize = true;
            this.addLabel.Font = new System.Drawing.Font("Bahnschrift Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.addLabel.Location = new System.Drawing.Point(300, 20);
            this.addLabel.Name = "addLabel";
            this.addLabel.Size = new System.Drawing.Size(301, 33);
            this.addLabel.TabIndex = 6;
            this.addLabel.Text = "ADDING NEW TEAM WITH PLAYERS";
            // 
            // teamNameTB
            // 
            this.teamNameTB.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.teamNameTB.Location = new System.Drawing.Point(12, 350);
            this.teamNameTB.Name = "teamNameTB";
            this.teamNameTB.Size = new System.Drawing.Size(174, 30);
            this.teamNameTB.TabIndex = 7;
            this.teamNameTB.Text = "Team name";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Bahnschrift Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameColumn,
            this.SurnameColumn,
            this.DateOfBirthColumn,
            this.ActiveStatusColumn,
            this.HealthStatusColumn,
            this.SalaryColumn});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Bahnschrift Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Location = new System.Drawing.Point(12, 60);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Bahnschrift Condensed", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(643, 277);
            this.dataGridView1.TabIndex = 9;
            // 
            // nameColumn
            // 
            this.nameColumn.Frozen = true;
            this.nameColumn.HeaderText = "Name";
            this.nameColumn.Name = "nameColumn";
            this.nameColumn.ReadOnly = true;
            // 
            // SurnameColumn
            // 
            this.SurnameColumn.Frozen = true;
            this.SurnameColumn.HeaderText = "Surname";
            this.SurnameColumn.Name = "SurnameColumn";
            this.SurnameColumn.ReadOnly = true;
            // 
            // DateOfBirthColumn
            // 
            this.DateOfBirthColumn.Frozen = true;
            this.DateOfBirthColumn.HeaderText = "Date of birth";
            this.DateOfBirthColumn.Name = "DateOfBirthColumn";
            this.DateOfBirthColumn.ReadOnly = true;
            // 
            // ActiveStatusColumn
            // 
            this.ActiveStatusColumn.Frozen = true;
            this.ActiveStatusColumn.HeaderText = "ActiveStatus";
            this.ActiveStatusColumn.Name = "ActiveStatusColumn";
            this.ActiveStatusColumn.ReadOnly = true;
            // 
            // HealthStatusColumn
            // 
            this.HealthStatusColumn.Frozen = true;
            this.HealthStatusColumn.HeaderText = "Health status";
            this.HealthStatusColumn.Name = "HealthStatusColumn";
            this.HealthStatusColumn.ReadOnly = true;
            // 
            // SalaryColumn
            // 
            this.SalaryColumn.Frozen = true;
            this.SalaryColumn.HeaderText = "Salary $";
            this.SalaryColumn.Name = "SalaryColumn";
            this.SalaryColumn.ReadOnly = true;
            // 
            // playerNameTB
            // 
            this.playerNameTB.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.playerNameTB.Location = new System.Drawing.Point(667, 60);
            this.playerNameTB.Name = "playerNameTB";
            this.playerNameTB.Size = new System.Drawing.Size(174, 30);
            this.playerNameTB.TabIndex = 10;
            this.playerNameTB.Text = "Name";
            // 
            // playerSurnameTB
            // 
            this.playerSurnameTB.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.playerSurnameTB.Location = new System.Drawing.Point(667, 99);
            this.playerSurnameTB.Name = "playerSurnameTB";
            this.playerSurnameTB.Size = new System.Drawing.Size(174, 30);
            this.playerSurnameTB.TabIndex = 11;
            this.playerSurnameTB.Text = "Surname";
            // 
            // datePicker
            // 
            this.datePicker.Font = new System.Drawing.Font("Bahnschrift Condensed", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.datePicker.Location = new System.Drawing.Point(665, 194);
            this.datePicker.Name = "datePicker";
            this.datePicker.Size = new System.Drawing.Size(174, 23);
            this.datePicker.TabIndex = 12;
            // 
            // ActiveStatusCB
            // 
            this.ActiveStatusCB.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.ActiveStatusCB.FormattingEnabled = true;
            this.ActiveStatusCB.Location = new System.Drawing.Point(665, 223);
            this.ActiveStatusCB.Name = "ActiveStatusCB";
            this.ActiveStatusCB.Size = new System.Drawing.Size(174, 31);
            this.ActiveStatusCB.TabIndex = 13;
            this.ActiveStatusCB.Text = "Active status";
            // 
            // healthStatusCB
            // 
            this.healthStatusCB.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.healthStatusCB.FormattingEnabled = true;
            this.healthStatusCB.Location = new System.Drawing.Point(665, 252);
            this.healthStatusCB.Name = "healthStatusCB";
            this.healthStatusCB.Size = new System.Drawing.Size(174, 31);
            this.healthStatusCB.TabIndex = 14;
            this.healthStatusCB.Text = "Health status";
            // 
            // salaryTB
            // 
            this.salaryTB.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.salaryTB.Location = new System.Drawing.Point(667, 135);
            this.salaryTB.Name = "salaryTB";
            this.salaryTB.Size = new System.Drawing.Size(174, 30);
            this.salaryTB.TabIndex = 15;
            this.salaryTB.Text = "Salary";
            // 
            // addPlayerButton
            // 
            this.addPlayerButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addPlayerButton.Font = new System.Drawing.Font("Bahnschrift Condensed", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.addPlayerButton.Location = new System.Drawing.Point(665, 289);
            this.addPlayerButton.Name = "addPlayerButton";
            this.addPlayerButton.Size = new System.Drawing.Size(174, 45);
            this.addPlayerButton.TabIndex = 16;
            this.addPlayerButton.Text = "Add player to team";
            this.addPlayerButton.UseVisualStyleBackColor = true;
            this.addPlayerButton.Click += new System.EventHandler(this.addPlayerButton_Click);
            // 
            // addTeamButton
            // 
            this.addTeamButton.BackColor = System.Drawing.Color.Lime;
            this.addTeamButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addTeamButton.Font = new System.Drawing.Font("Bahnschrift Condensed", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.addTeamButton.Location = new System.Drawing.Point(12, 385);
            this.addTeamButton.Name = "addTeamButton";
            this.addTeamButton.Size = new System.Drawing.Size(174, 45);
            this.addTeamButton.TabIndex = 17;
            this.addTeamButton.Text = "Add team";
            this.addTeamButton.UseVisualStyleBackColor = false;
            this.addTeamButton.Click += new System.EventHandler(this.addTeamButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(710, 167);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 23);
            this.label1.TabIndex = 18;
            this.label1.Text = "Date of birth";
            // 
            // AddTeamForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(849, 442);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.addTeamButton);
            this.Controls.Add(this.addPlayerButton);
            this.Controls.Add(this.salaryTB);
            this.Controls.Add(this.healthStatusCB);
            this.Controls.Add(this.ActiveStatusCB);
            this.Controls.Add(this.datePicker);
            this.Controls.Add(this.playerSurnameTB);
            this.Controls.Add(this.playerNameTB);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.teamNameTB);
            this.Controls.Add(this.addLabel);
            this.Controls.Add(this.exitButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddTeamForm";
            this.Text = "Adding team and players";
            this.Load += new System.EventHandler(this.AddTeamForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label addLabel;
        private System.Windows.Forms.TextBox teamNameTB;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn SurnameColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn DateOfBirthColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ActiveStatusColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn HealthStatusColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn SalaryColumn;
        private System.Windows.Forms.TextBox playerNameTB;
        private System.Windows.Forms.TextBox playerSurnameTB;
        private System.Windows.Forms.DateTimePicker datePicker;
        private System.Windows.Forms.ComboBox ActiveStatusCB;
        private System.Windows.Forms.ComboBox healthStatusCB;
        private System.Windows.Forms.TextBox salaryTB;
        private System.Windows.Forms.Button addPlayerButton;
        private System.Windows.Forms.Button addTeamButton;
        private System.Windows.Forms.Label label1;
    }
}