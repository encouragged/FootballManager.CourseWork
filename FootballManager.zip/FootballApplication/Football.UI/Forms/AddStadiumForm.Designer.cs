﻿
namespace Football.UI.Forms
{
    partial class AddStadiumForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.exitButton = new System.Windows.Forms.Button();
            this.addStadiumLabel = new System.Windows.Forms.Label();
            this.nameTB = new System.Windows.Forms.TextBox();
            this.seatsTB = new System.Windows.Forms.TextBox();
            this.addButton = new System.Windows.Forms.Button();
            this.priceTB = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.Red;
            this.exitButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exitButton.Location = new System.Drawing.Point(261, 12);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.UseVisualStyleBackColor = false;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // addStadiumLabel
            // 
            this.addStadiumLabel.AutoSize = true;
            this.addStadiumLabel.Font = new System.Drawing.Font("Bahnschrift Condensed", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.addStadiumLabel.Location = new System.Drawing.Point(62, 41);
            this.addStadiumLabel.Name = "addStadiumLabel";
            this.addStadiumLabel.Size = new System.Drawing.Size(202, 33);
            this.addStadiumLabel.TabIndex = 5;
            this.addStadiumLabel.Text = "ADDING NEW STADIUM";
            // 
            // nameTB
            // 
            this.nameTB.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.nameTB.Location = new System.Drawing.Point(74, 82);
            this.nameTB.Name = "nameTB";
            this.nameTB.Size = new System.Drawing.Size(174, 30);
            this.nameTB.TabIndex = 6;
            this.nameTB.Text = "Name";
            // 
            // seatsTB
            // 
            this.seatsTB.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.seatsTB.Location = new System.Drawing.Point(74, 121);
            this.seatsTB.Name = "seatsTB";
            this.seatsTB.Size = new System.Drawing.Size(174, 30);
            this.seatsTB.TabIndex = 7;
            this.seatsTB.Text = "Seats";
            // 
            // addButton
            // 
            this.addButton.BackColor = System.Drawing.Color.Lime;
            this.addButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addButton.Font = new System.Drawing.Font("Bahnschrift Condensed", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.addButton.Location = new System.Drawing.Point(74, 196);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(174, 49);
            this.addButton.TabIndex = 8;
            this.addButton.Text = "Add stadium";
            this.addButton.UseVisualStyleBackColor = false;
            this.addButton.Click += new System.EventHandler(this.addButton_Click);
            // 
            // priceTB
            // 
            this.priceTB.Font = new System.Drawing.Font("Bahnschrift Condensed", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.priceTB.Location = new System.Drawing.Point(74, 160);
            this.priceTB.Name = "priceTB";
            this.priceTB.Size = new System.Drawing.Size(174, 30);
            this.priceTB.TabIndex = 9;
            this.priceTB.Text = "Price per seats";
            // 
            // AddStadiumForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(344, 276);
            this.Controls.Add(this.priceTB);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.seatsTB);
            this.Controls.Add(this.nameTB);
            this.Controls.Add(this.addStadiumLabel);
            this.Controls.Add(this.exitButton);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddStadiumForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddStadiumForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label addStadiumLabel;
        private System.Windows.Forms.TextBox nameTB;
        private System.Windows.Forms.TextBox seatsTB;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.TextBox priceTB;
    }
}