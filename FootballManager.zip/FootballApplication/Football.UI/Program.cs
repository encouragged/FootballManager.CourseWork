using Football.Core.Services;
using Football.Data;
using Football.Data.Repositories;
using Football.UI.Forms;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Football.UI
{
    static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var services = new ServiceCollection();

            ConfigureServices(services);

            using (ServiceProvider serviceProvider = services.BuildServiceProvider())
            {
                var mainForm = serviceProvider.GetRequiredService<ManagerForm>();
                Application.Run(mainForm);
            }
        }

        private static void ConfigureServices(ServiceCollection services)
        {
            services
                // DI DAL
                .AddSingleton<FootballContext>()
                .AddSingleton<TeamRepository>()
                .AddSingleton<StadiumRepository>()
                .AddSingleton<PlayerRepository>()
                .AddSingleton<GameRepository>()
                // DI BA Services
                .AddSingleton<StadiumService>()
                .AddSingleton<TeamWithPlayersService>()
                .AddSingleton<GameService>()
                // DI Forms
                .AddSingleton<AddStadiumForm>()
                .AddSingleton<AddGameForm>()
                .AddSingleton<AddTeamForm>()
                .AddSingleton<DetailInformationForm>()
                .AddSingleton<ManagerForm>();
            
            

        }
    }
}
